package com.mercury.bean;

import org.springframework.stereotype.Component;

@Component
public class HistoryBook implements Book{
}
