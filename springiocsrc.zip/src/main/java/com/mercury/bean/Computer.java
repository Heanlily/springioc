package com.mercury.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.inject.Inject;

@Component
public class Computer {

    //@Autowired
    @Inject
    private CPU cpu;
    private int x;

    public Computer() {
    }

   // @Autowired //first autowire by type, if found only one match, it will inject matched bean
    //if found multiple matched type beans, it will autowire by name.
    //if name match cannot find, throw exception
    public Computer(CPU cpu) {
        this.cpu = cpu;
    }

    public CPU getCpu() {
        return cpu;
    }

    //setter injection
    //@Resource(name = "cpu") //first byname, than bytype
    public void setCpu(CPU cpu) {
        this.cpu = cpu;
    }

    @Override
    public String toString() {
        return "Computer{" +
                "cpu=" + cpu +
                '}';
    }
}
