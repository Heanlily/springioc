package com.mercury.bean;

public interface Book {
}
