package com.mercury.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Student {
    @Autowired
    @Qualifier(value = "historyBook")
    Book book;

    @Override
    public String toString() {
        return "Student{" +
                "book=" + book.getClass().getName() +
                '}';
    }
}
