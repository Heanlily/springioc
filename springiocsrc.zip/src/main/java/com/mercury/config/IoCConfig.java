package com.mercury.config;

import com.mercury.bean.CPU;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = {"com.mercury.bean"})
public class IoCConfig {
    @Bean
    public CPU cpu1() {
        return new CPU("Intel","i7");
    }

    @Bean(name = "cpu2")
    public CPU createCPU() {
        return new CPU("AMD","i7");
    }

    @Bean
    public CPU cpu() {
        return new CPU("AMD","i7");
    }
}
