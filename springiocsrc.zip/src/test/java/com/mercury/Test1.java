package com.mercury;

import com.mercury.bean.CPU;
import com.mercury.bean.Computer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test1 {
    public static void main(String[] args) {
        //how to create a container for spring objects
        //1.BeanFactory
        //2.ApplicationContext

        //resource folder is on class path
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("iocconfig.xml");
        //how to get objects from container
        CPU cpu1 = (CPU) applicationContext.getBean("cpu1");
        CPU cpu1Another = (CPU) applicationContext.getBean("cpu1");

        System.out.println(cpu1 == cpu1Another);

        Computer computer1 = (Computer) applicationContext.getBean("computer1");
        System.out.println(computer1);

        //
        Computer computer2 = (Computer) applicationContext.getBean("computer2");
        System.out.println(computer2);

        Computer computer3 = (Computer) applicationContext.getBean("computer");
        System.out.println(computer3);


    }
}
