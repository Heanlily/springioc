package com.mercury;

import com.mercury.bean.CPU;
import com.mercury.bean.Computer;
import com.mercury.bean.Counter;
import com.mercury.bean.Student;
import com.mercury.config.IoCConfig;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test2 {
    public static void main(String[] args) {
        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(IoCConfig.class);
        CPU cpu1 = (CPU) applicationContext.getBean("cpu1");
        System.out.println(cpu1);

        CPU cpu2 = (CPU) applicationContext.getBean("cpu2");
        System.out.println(cpu2);

        //class name is CPU, bean name is CPU
        //..............Computer,........computer

        CPU cpu = (CPU) applicationContext.getBean("cpu");
        System.out.println(cpu);

//        not found unless add @Component
        Computer computer = (Computer) applicationContext.getBean("computer");
        System.out.println(computer);

        Student student = (Student) applicationContext.getBean("student");
        System.out.println(student);

        //by default, spring create object in the container eagerly.
        System.out.println(Counter.getCount()); //0
        Counter counter = (Counter) applicationContext.getBean("counter");
        System.out.println(Counter.getCount()); //1

    }
}
